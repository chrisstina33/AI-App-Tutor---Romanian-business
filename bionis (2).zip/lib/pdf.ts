import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

function escapeHtml(value: string): string {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

export async function generateLearningPdf(title: string, sections: Array<{ heading: string; body: string }>): Promise<boolean> {
  const body = sections.map((section) => `<section><h2>${escapeHtml(section.heading)}</h2><div>${escapeHtml(section.body).replace(/\n/g, "<br />")}</div></section>`).join("");
  const html = `<!doctype html><html lang="ro"><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;color:#171a32;padding:32px;line-height:1.55}h1{color:#12152a;border-bottom:3px solid #8a72ff;padding-bottom:12px}h2{color:#6d58dc;margin-top:26px}section{page-break-inside:avoid}.formula{font-family:monospace;background:#f2efff;padding:4px 6px}</style></head><body><h1>${escapeHtml(title)}</h1>${body}<footer><p>Creat cu Elunariq · învață prin următorul pas</p></footer></body></html>`;
  const result = await Print.printToFileAsync({ html });
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(result.uri, { mimeType: "application/pdf", dialogTitle: "Partajează recapitularea Elunariq" });
  return true;
}
